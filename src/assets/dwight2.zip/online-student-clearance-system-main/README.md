# Online-Student-Clearance-System

This is a working proof of concept of a PHP, SQL and Javascript Application that clears Students online from an institution like a college before they graduate. It only includes the basic functions like Registration, Login, Update clearance details and status, view clearance details and status on both admin and student side, clear student on admin side on each department, log out.

# Authentication

The admin username and password are 'jack' and 'jack' ..you can register new students and login with the Registration number as username and the password you provide.

# Development

Download and use on localhost with either Xampp Wamp or Mamp

# Author

[@JackMkimbo](https://twitter.com/JackMkimbo)
