$(document).ready(function(){
   alert('t');
});