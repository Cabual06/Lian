<div id="page-wrapper">
<?php
session_start();
if(isset($_SESSION['student_id'])){
	
}else{
	echo "<script>window.location='studentLogin.php'</script>";
}
include('inc/top-stats.php');?>
<div class="row">
    <div class="col-lg-12">
     
    </div>
</div>

